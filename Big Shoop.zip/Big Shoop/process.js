// kita include module yang diperlukan disini
import fs from 'fs';
import path from 'path';
import archiver from 'archiver';
import fetch from 'node-fetch';
import { exec } from 'child_process';

// eits, jagan lupa confignya
import cnf from './config.js'

// seperti biasa, shortcut 
const log = console.log;

import { fileURLToPath } from 'url';
import { dirname } from 'path';

// Dapatkan path file saat ini
const __filename = fileURLToPath(import.meta.url);

// Dapatkan direktori file saat ini
const __dirname = dirname(__filename);

// Fungsi untuk menghasilkan tanggal dan waktu dengan format DD-MM-YY_HH-MM
function generateDateTime() {
    const now = new Date();

    // Menentukan format DD, MM, YY, HH, dan MM
    const day = String(now.getDate()).padStart(2, '0'); // Menambahkan 0 di depan jika < 10
    const month = String(now.getMonth() + 1).padStart(2, '0'); // Bulan dimulai dari 0, jadi ditambah 1
    const year = String(now.getFullYear()).slice(-2); // Mengambil 2 digit terakhir dari tahun
    const hours = String(now.getHours()).padStart(2, '0'); // Jam
    const minutes = String(now.getMinutes()).padStart(2, '0'); // Menit

    // Menggabungkan menjadi format DD-MM-YY_HH-MM
    return `${day}-${month}-${year}_${hours}-${minutes}`;
}

export class DO {
    // kita buat contructor buat intro intro aja
    constructor() {
        log("[ INFO ] Starting process...");
    }

    // method buat ngezip database
    async ZipDatabase() {
        
        // gtw ini kopas dari gpt

        // system akan write secara streaming ya, jadi gak nunggu selesai baru di write filenya 
        const output = fs.createWriteStream(path.join(__dirname, "ocean.zip"));
        const archive = archiver('zip', { zlib: { level: 9 } }); // Kompresi maksimal -> kacawwww

        // buat perjanjian, jgn diingkari
        return new Promise((resolve, reject) =>{
            // ini event listener kalo gak salah, nanti kalo filenya sudah di close/proses write selesai akan menampilkan peringatan 
            output.on('close', () => {
                console.log(`[ SUCESS ] ZIP selesai: ${path.join(__dirname)} (${archive.pointer()} bytes)`);
                resolve();
            });

            archive.on('error', (err) => {
                log(`[ ERROR ] Zip error: ${err.message}`);
            });

            archive.on('error', (err) => reject(err));
            archive.pipe(output);

            // Tambahkan semua file dalam folder ke ZIP
            archive.directory(cnf.path_db, false);  // Pastikan folder path benar
            archive.finalize();  // Pastikan finalize berjalan dengan benar
        });
    }

    // method buat upload zip
    async Backup() {
        try {
            // capek ngetik wak, cari sendiri aja
            const file = fs.readFileSync(path.join(__dirname, "ocean.zip"));
            const name = `Ocean_Forum_${generateDateTime()}.zip`;
            const response = await fetch(`https://pixeldrain.com/api/file/` + name, {
                method: 'PUT',
                headers: {
                    "Authorization": "Basic "+btoa(":"+cnf.api_key),
                    'Content-Type': 'application/octet-stream'
                },
                body: file
            });
    
            if (!response.ok) {
                throw new Error(`[ ERROR ] Gagal mengunggah: ${response.statusText}`);
            }
    
            console.log(`[ SUCCESS ] Berhasil mengunggah ${name}: ` + response.statusText);

            // Hapus file ocean.zip setelah upload berhasil
            fs.unlinkSync(path.join(__dirname, "ocean.zip"));
            console.log(`[ INFO ] File ocean.zip telah dihapus setelah upload berhasil.`);
        } catch (error) {
            console.error(`[ ERROR ] ${error.message}`);
        }
    }

    // method buat hapus ocean.rar dari recycle bin dan countdown 10 detik lalu exit
    async DeleteAndCountdown() {
        try {
            log("[ INFO ] Deleting ocean.rar from Recycle Bin...");
            // Gunakan PowerShell untuk menghapus file dari recycle bin berdasarkan nama asli
            const command = `powershell -Command "Get-ChildItem -Path 'C:\\\\$Recycle.Bin' -Recurse -Filter 'ocean.rar' | Remove-Item -Force"`;
            await new Promise((resolve, reject) => {
                exec(command, (error, stdout, stderr) => {
                    if (error) {
                        reject(new Error(`[ ERROR ] Failed to delete file: ${error.message}`));
                    } else {
                        log("[ SUCCESS ] File ocean.rar deleted from Recycle Bin.");
                        resolve();
                    }
                });
            });

            log("[ INFO ] Counting down 10 seconds...");
            for (let i = 10; i > 0; i--) {
                log(i);
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
            log("[ INFO ] Exiting process...");
            process.exit(0);
        } catch (error) {
            console.error(`[ ERROR ] ${error.message}`);
        }
    }
}
