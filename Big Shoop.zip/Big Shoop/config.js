export default {
    // Your api key (get it from https://pixeldrain.com)
    api_key: "ed726a78-cb16-4837-89ea-63e4b16637ba",

    // delay backup (hour)
    delay: 1,

    // Path to your database folder
    path_db: "../script mahal/"
}