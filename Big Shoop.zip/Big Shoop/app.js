// hubungkan file config kesini
import cnf from './config.js'
import fs from 'node:fs'
import {DO} from './process.js'

// pintasan aja, males soalnya
const log = console.log;

// main function yang akan dieksekusi oleh sistem
(async()=>{
    // async biar singkron kayak hubungan kita :>

    // ini pastiin kalo user udah masang api_key, aneh kalo masih kosong. gak punya? ambil aja di https://pixeldrain.com jangan lupa register kalo belum ada akun
    if (cnf.api_key == "") {
        log("[ ERROR ] Please provide your secret api key in config.js");
        return;
    }

    // di cek dulu pathnya udah vakid atau gak, yakali mau backup harapan
    if (!fs.existsSync(cnf.path_db)) {
        log("[ ERROR ] Path not found or invalid path");
        return;
    }

    // antisipasi buat user kalo iseng set delay dibawah atau sama dengan 0
    if (cnf.delay <= 0) {
        // kita atur ke default
        cnf.delay = 1;
    }

    // jah kalo sudah lulus semua textnya tinggal eksekusi aja
    // eksekusi pertama kali
    // bikin objek baru, biar keliatan pro kodeir
    let gas = new DO();

    // di zip dulu databasenya
    await gas.ZipDatabase();
    // baru diupload 
    await gas.Backup();
    
    // pake loop seumur hidup
    setInterval(async()=>{
        // bikin objek baru, biar keliatan pro kodeir
        let gas = new DO();

        // di zip dulu databasenya
        await gas.ZipDatabase();
        // baru diupload 
        await gas.Backup();
    }, 3600000 * cnf.delay);
})();